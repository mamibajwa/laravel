<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beyond Academy</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 50px;
            height: auto;
            margin-right: 10px;
        }
        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            list-style: none;
            padding: 0;
        }
        .nav li {
            margin-right: 20px;
        }
        .nav a {
            text-decoration: none;
            color: #333;
        }
        .title {
            font-size: 32px;
            font-weight: bold;
            color: #f00;
            margin-bottom: 20px;
        }
        .step {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .step-number {
            width: 50px;
            height: 100%;
            background-color: #f00;
            margin-right: 20px;
        }
        .step-text {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        .form-group {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .form-group label {
            font-size: 16px;
            font-weight: bold;
            color: #333;
        }
        .form-group select {
            width: 48%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .button {
            background-color: #f00;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">
                <img src="logo.png" alt="Beyond Academy Logo">
                <h1>Beyond Academy</h1>
            </div>
            <ul class="nav">
                <li><a href="#">View Our Testimonials</a></li>
                <li><button class="button">Apply Now</button></li>
                <li><i class="fa fa-bars"></i></li>
            </ul>
        </div>
        <h2 class="title">Start Dates & Apply</h2>
        <div class="step">
            <div class="step-number"></div>
            <div class="step-text">Step 1</div>
        </div>
        <div class="form-group">
            <label for="location">CHOOSE YOUR</label>
        </div>
        <div class="form-group">
            <label for="location">Location</label>
            <select name="location" id="location">
                <option value="">Select Location</option>
                <option value="location1">Location 1</option>
                <option value="location2">Location 2</option>
            </select>
            <label for="industry">Industry</label>
            <select name="industry" id="industry">
                <option value="">Select Industry</option>
                <option value="industry1">Industry 1</option>
                <option value="industry2">Industry 2</option>
            </select>
        </div>
    </div>
</body>
</html>