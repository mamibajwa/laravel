<?php

use Illuminate\Support\Facades\Route;
use  App\Http\Controllers\admin;

Route::get('/', function () {
    return view('welcome');
});


Route::get('/internpage', [admin::class, 'internpage']);
Route::post('/get-industries', [admin::class, 'getIndustries']);
Route::post('/get-fields', [admin::class, 'getFields']);

Route::get('/admin', [admin::class, 'display'])->name('admin');

Route::get('/form', [admin::class, 'form'])->name('form');
Route::get('/icons', [admin::class, 'icon'])->name('icons');
Route::get('/login', [admin::class, 'login'])->name('login');
Route::get('/register', [admin::class, 'register'])->name('register');
Route::get('/passwordreset', [admin::class, 'passwordreset'])->name('passwordreset');
Route::get('/industry', [admin::class, 'add_industry'])->name('add.industry');
Route::get('/profile', [admin::class, 'profile'])->name('profile');
use App\Http\Controllers\CityController;
Route::post('/cities', [CityController::class, 'store'])->name('cities.store');
Route::get('/cities', [CityController::class, 'display'])->name('allcities');
use  App\Http\Controllers\authenticaton;
Route::post('/signup', [authenticaton::class, 'signup'])->name('signup');
Route::post('/login', [authenticaton::class, 'login'])->name('login.user');

use App\Http\Controllers\IndustryController;

Route::post('/industries', [IndustryController::class, 'store'])->name('industries.store');
Route::get('/industries', [IndustryController::class, 'index'])->name('index.industry');



Route::get('/index', [admin::class, 'index'])->name('index');

