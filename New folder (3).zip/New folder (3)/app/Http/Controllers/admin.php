<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\City; // Import the City model
use App\Models\Industry;
class admin extends Controller
{
  
    public function internpage()
    {
        $cities = Industry::select('city')->distinct()->get();
        return view('form', compact('cities'));
    }

    public function getIndustries(Request $request)
    {
        $industries = Industry::where('city', $request->city)->get();
        return response()->json($industries);
    }

    public function getFields(Request $request)
    {
        $fields = Industry::where('city', $request->city)
                          ->where('industry', $request->industry)
                          ->pluck('field');
        return response()->json($fields);
    }
    
    public function form()
    {
        $cities = City::all(); 
        return view('addcity', compact('cities'));
    }

    public function icon()
    {
        return view('icons');
    }

    public function login()
    {
        return view('login');
    }

    public function profile()
    {
        return view('profile');
    }

    public function register()
    {
        return view('register');
    }

    public function passwordreset()
    {
        return view('reset-password');
    }

    public function add_industry()
    {
        $cities = City::all();
        return view('addindustry', compact('cities'));
    }
    public function display(){
        return view('index');
    }
    public function index (){
        view('intern');
     }
}
